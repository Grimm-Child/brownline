(function($) {
	$(document).ready(function() {
	  $("div.inline-group").wrapInner("<fieldset class=\"module aligned collapse\"></fieldset>");
	});
})(django.jQuery);